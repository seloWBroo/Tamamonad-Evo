let statusEl = document.getElementById('status');

function feed() {
    statusEl.textContent = "Status: Full 🍖";
}

function play() {
    statusEl.textContent = "Status: Excited 😆";
}
