
let statusText = document.getElementById('status');
let pet = document.getElementById('pet');

function feed() {
    statusText.innerText = "Status: Full 🍗";
    pet.style.transform = "scale(1.1)";
    setTimeout(() => pet.style.transform = "scale(1)", 500);
}

function play() {
    statusText.innerText = "Status: Excited 🎮";
    pet.style.transform = "rotate(10deg)";
    setTimeout(() => pet.style.transform = "rotate(0deg)", 500);
}
